#!/usr/bin/env python3

from brain_games.cli_brain_calc import brain_calc

def main():
    brain_calc()
    
if __name__ == '__main__':
    main()
