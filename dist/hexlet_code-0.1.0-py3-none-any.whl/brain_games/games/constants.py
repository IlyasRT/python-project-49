number_of_repetitions = 3
