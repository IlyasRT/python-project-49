NUMBER_OF_REPETITIONS = 3
ANSWER_FOR_USER_1 = ' is wrong answer;(. Correct answer was '
ANSWER_FOR_USER_2 = 'Let\'s try again, '
