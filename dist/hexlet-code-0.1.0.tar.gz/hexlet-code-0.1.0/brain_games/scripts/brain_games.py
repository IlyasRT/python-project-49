#!/usr/bin/env python3


from brain_games.cli import welcome_user

main
welcome_user
