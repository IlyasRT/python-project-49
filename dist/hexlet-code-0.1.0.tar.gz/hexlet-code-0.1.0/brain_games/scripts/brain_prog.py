#!/usr/bin/env python3
from brain_games.games.cli_brain_prog import brain_prog


def main():
    brain_prog()


if __name__ == '__main__':
    main()
