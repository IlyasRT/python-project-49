#!/usr/bin/env python3
from random import randint
from prompt import string
def main():
    print('Answer "yes" if the number is even, otherwise answer "no".')
    rnd_number=random.randint(0, 100)
    print(f'Question:{rnd_number}')
    your_answer = prompt.string('Your answer:')
    if rnd_number%2==0 and  your_answer=='yes':
    	print(f'Correct!')
    elif rnd_number%2!=0 and  your_answer=='no':
    	print(f'Correct!')
    	
    else:
    	print(f'')
    'yes' is wrong answer ;(. Correct answer was 'no'.
Let's try again, Bill!
    
    

main
