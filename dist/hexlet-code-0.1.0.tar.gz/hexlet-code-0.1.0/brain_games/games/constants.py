NUMBER_OF_REPETITIONS = 3
A_YES = '\'yes\' is wrong answer;(. Correct answer was \'no\'.'
A_CM = 'Let\'s try again, '
A_NO = '\'no\' is wrong answer;(. Correct answer was \'yes\'.'
